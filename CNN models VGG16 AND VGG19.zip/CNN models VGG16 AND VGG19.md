```python
import pandas as pd
import numpy as np
import cv2
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
%matplotlib inline
import seaborn as sns
import random
import os
import gc

from tensorflow import keras
from keras import layers
from keras import models, Sequential
from keras import optimizers
from keras.applications.xception import Xception
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D, SeparableConv2D
from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.preprocessing import image
from keras.applications.vgg16 import VGG16

from keras.preprocessing.image import ImageDataGenerator
from keras.preprocessing.image import img_to_array, load_img

from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import precision_recall_curve
```


```python
# Creating file path for our train data and test data
train_dir = "AutismDataset/train"
test_dir = "AutismDataset/test"
```


```python
# Getting 'Autistic' and 'Non-Autistic' train images from respective file names of train data
train_non_autistic = []
train_autistic = []
for i in os.listdir(train_dir):
    if 'Non_Autistic' in ("AutismDataset/train/{}".format(i)):
        train_non_autistic.append(("AutismDataset/train/{}".format(i)))
    else:
        train_autistic.append(("AutismDataset/train/{}".format(i)))

# Getting test images from test data file path
test_imgs = ["AutismDataset/test/{}".format(i) for i in os.listdir(test_dir)]


# Concatenate 'Autistic'  and 'Non-Autistic' images and shuffle them as train_images
train_imgs = train_autistic + train_non_autistic
random.shuffle(train_imgs)

# Remove the lists to save space
del train_autistic
del train_non_autistic
gc.collect()
     
```




    1281




```python
# Set the dimensions for images
nrows = 150
ncolumns  = 150
channels = 3

# Read and process the images: Function returns X,y. X - list of resized images, y - list of labels for the images

def read_and_process_image(list_of_images):
    X = []
    y = []

    for image in list_of_images:
        X.append(cv2.resize(cv2.imread(image, cv2.IMREAD_COLOR), (nrows, ncolumns), interpolation = cv2.INTER_CUBIC))
        if 'Non_Autistic' in image:
            y.append(0)
        else:
            y.append(1)

    return X,y
```


```python
# Get resized images and labels from train data
X_train, y_train = read_and_process_image(train_imgs)

# Delete train images to save space
del train_imgs
gc.collect()

```




    0




```python
# Convert the lists to array
plt.figure(figsize=(12, 8))
X_train = np.array(X_train)
y_train = np.array(y_train)
sns.countplot(y_train, saturation=1)
plt.title("Train image labels")
```




    Text(0.5, 1.0, 'Train image labels')




    
![png](output_5_1.png)
    



```python
# Shape of train images and labels
print("Shape of train images:", X_train.shape)
print("Shape of train labels:", y_train.shape)
```

    Shape of train images: (2540, 150, 150, 3)
    Shape of train labels: (2540,)
    


```python
# Repeat the above process for validation data to get val_images
val_autistic = "AutismDataset/valid/Autistic"
val_non_autistic = "AutismDataset/valid/Non_Autistic"
val_autistic_imgs = ["AutismDataset/valid/Autistic/{}".format(i) for i in os.listdir(val_autistic)]
val_non_autistic_imgs = ["AutismDataset/valid/Non_Autistic/{}".format(i) for i in os.listdir(val_non_autistic)]
val_imgs = val_autistic_imgs + val_non_autistic_imgs
random.shuffle(val_imgs)

# Remove the lists to save space
del val_autistic_imgs
del val_non_autistic_imgs
gc.collect()
```




    35




```python
# Get resized images and labels from validation data
X_val, y_val = read_and_process_image(val_imgs)

# Delete validation images to save space
del val_imgs
gc.collect()
```




    0




```python
# Convert the lists to array
plt.figure(figsize=(12, 8))
X_val = np.array(X_val)
y_val = np.array(y_val)
sns.countplot(y_val, saturation=1)
plt.title("Validation image labels")
```




    Text(0.5, 1.0, 'Validation image labels')




    
![png](output_9_1.png)
    



```python
# Shape of validation images and labels
print("Shape of validation images:", X_val.shape)
print("Shape of validation labels:", y_val.shape)
```

    Shape of validation images: (100, 150, 150, 3)
    Shape of validation labels: (100,)
    


```python
# Get length of train data and validation data
ntrain = len(X_train)
nval = len(X_val)
batch_size = 32
```

#VGG16 Model Implementation


```python
# Calling pre-trained VGG16 model
base_model = VGG16(include_top=False,weights='imagenet',input_shape=(150,150,3))
```


```python
#vgg16
print("Number of layers in the base model: ", len(base_model.layers))
     
```

    Number of layers in the base model:  19
    


```python
# Freeze the layers in pre-trained model, we don't need to train again
for layer in base_model.layers:
   layer.trainable = False
```


```python
# Create our classifier model, connect pre-trained model vgg to our model
model = keras.models.Sequential()
model.add(base_model)
model.add(layers.MaxPooling2D(pool_size=(2, 2)))
model.add(layers.Flatten())
model.add(layers.Dense(512, activation = 'relu'))
model.add(layers.Dropout(0.5))
model.add(layers.Dense(1, activation = 'sigmoid'))
```


```python
# Create summary of our model
model.summary()
```

    Model: "sequential"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     vgg16 (Functional)          (None, 4, 4, 512)         14714688  
                                                                     
     max_pooling2d (MaxPooling2  (None, 2, 2, 512)         0         
     D)                                                              
                                                                     
     flatten (Flatten)           (None, 2048)              0         
                                                                     
     dense (Dense)               (None, 512)               1049088   
                                                                     
     dropout (Dropout)           (None, 512)               0         
                                                                     
     dense_1 (Dense)             (None, 1)                 513       
                                                                     
    =================================================================
    Total params: 15764289 (60.14 MB)
    Trainable params: 1049601 (4.00 MB)
    Non-trainable params: 14714688 (56.13 MB)
    _________________________________________________________________
    


```python
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
```


```python
# Configure data augumentation and scaling of images to prevent overfitting since we have a small train data
train_datagen = ImageDataGenerator(rescale = 1./255,
                                  rotation_range = 40,
                                  width_shift_range = 0.2,
                                  height_shift_range = 0.2,
                                  shear_range = 0.2,
                                  zoom_range = 0.2,
                                  horizontal_flip = True)

# Only rescaling for validation data
val_datagen = ImageDataGenerator(rescale = 1./255)
     
```


```python
X_test, y_test = read_and_process_image(test_imgs)
del test_imgs
gc.collect()
```




    839




```python
plt.figure(figsize=(12, 8))
X_test = np.array(X_test)
y_test = np.array(y_test)
sns.countplot(y_val, saturation=1)
plt.title("Test image labels")
     
```




    Text(0.5, 1.0, 'Test image labels')




    
![png](output_21_1.png)
    



```python
# Create test and validation image generator
BATCH_SIZE = 64
X_train = np.array(X_train)
y_train = np.array(y_train)
X_test = np.array(X_test)
y_test = np.array(y_test)
X_val = np.array(X_val)
y_val = np.array(y_val)
train_generator = train_datagen.flow(X_train, y_train, batch_size = BATCH_SIZE)
val_generator = val_datagen.flow(X_val, y_val, batch_size = BATCH_SIZE)
```


```python
# Train the model
#early_stopping = keras.callbacks.EarlyStopping(monitor="val_loss", patience=3)

# Entrenar el modelo
history = model.fit(train_generator,
                              epochs=40,
                              validation_data=val_generator,
                              #callbacks=[early_stopping],
                              workers=8,
                              use_multiprocessing=False
                             )
```

    Epoch 1/40
    40/40 [==============================] - 227s 6s/step - loss: 0.5057 - accuracy: 0.7508 - val_loss: 0.5281 - val_accuracy: 0.6900
    Epoch 2/40
    40/40 [==============================] - 231s 6s/step - loss: 0.4971 - accuracy: 0.7500 - val_loss: 0.5028 - val_accuracy: 0.7500
    Epoch 3/40
    40/40 [==============================] - 234s 6s/step - loss: 0.4887 - accuracy: 0.7543 - val_loss: 0.5427 - val_accuracy: 0.7100
    Epoch 4/40
    40/40 [==============================] - 243s 6s/step - loss: 0.4973 - accuracy: 0.7449 - val_loss: 0.5096 - val_accuracy: 0.7400
    Epoch 5/40
    40/40 [==============================] - 251s 6s/step - loss: 0.4950 - accuracy: 0.7500 - val_loss: 0.5078 - val_accuracy: 0.7300
    Epoch 6/40
    40/40 [==============================] - 249s 6s/step - loss: 0.4954 - accuracy: 0.7508 - val_loss: 0.5251 - val_accuracy: 0.7200
    Epoch 7/40
    40/40 [==============================] - 245s 6s/step - loss: 0.4998 - accuracy: 0.7555 - val_loss: 0.5341 - val_accuracy: 0.7200
    Epoch 8/40
    40/40 [==============================] - 240s 6s/step - loss: 0.4907 - accuracy: 0.7524 - val_loss: 0.5218 - val_accuracy: 0.7300
    Epoch 9/40
    40/40 [==============================] - 243s 6s/step - loss: 0.4862 - accuracy: 0.7650 - val_loss: 0.5272 - val_accuracy: 0.7100
    Epoch 10/40
    40/40 [==============================] - 242s 6s/step - loss: 0.4691 - accuracy: 0.7709 - val_loss: 0.5017 - val_accuracy: 0.7500
    Epoch 11/40
    40/40 [==============================] - 241s 6s/step - loss: 0.4910 - accuracy: 0.7571 - val_loss: 0.5429 - val_accuracy: 0.7100
    Epoch 12/40
    40/40 [==============================] - 243s 6s/step - loss: 0.4783 - accuracy: 0.7646 - val_loss: 0.5186 - val_accuracy: 0.7400
    Epoch 13/40
    40/40 [==============================] - 252s 6s/step - loss: 0.4780 - accuracy: 0.7579 - val_loss: 0.5053 - val_accuracy: 0.7300
    Epoch 14/40
    40/40 [==============================] - 279s 7s/step - loss: 0.4762 - accuracy: 0.7575 - val_loss: 0.4885 - val_accuracy: 0.7500
    Epoch 15/40
    40/40 [==============================] - 271s 7s/step - loss: 0.4653 - accuracy: 0.7693 - val_loss: 0.5186 - val_accuracy: 0.7600
    Epoch 16/40
    40/40 [==============================] - 268s 7s/step - loss: 0.4740 - accuracy: 0.7650 - val_loss: 0.5485 - val_accuracy: 0.7000
    Epoch 17/40
    40/40 [==============================] - 267s 7s/step - loss: 0.4727 - accuracy: 0.7646 - val_loss: 0.5246 - val_accuracy: 0.7300
    Epoch 18/40
    40/40 [==============================] - 296s 7s/step - loss: 0.4697 - accuracy: 0.7618 - val_loss: 0.5016 - val_accuracy: 0.7600
    Epoch 19/40
    40/40 [==============================] - 312s 8s/step - loss: 0.4791 - accuracy: 0.7559 - val_loss: 0.5081 - val_accuracy: 0.7200
    Epoch 20/40
    40/40 [==============================] - 360s 9s/step - loss: 0.4605 - accuracy: 0.7689 - val_loss: 0.5075 - val_accuracy: 0.7300
    Epoch 21/40
    40/40 [==============================] - 314s 8s/step - loss: 0.4626 - accuracy: 0.7752 - val_loss: 0.5150 - val_accuracy: 0.7600
    Epoch 22/40
    40/40 [==============================] - 295s 7s/step - loss: 0.4602 - accuracy: 0.7831 - val_loss: 0.5221 - val_accuracy: 0.7000
    Epoch 23/40
    40/40 [==============================] - 288s 7s/step - loss: 0.4704 - accuracy: 0.7673 - val_loss: 0.4984 - val_accuracy: 0.7200
    Epoch 24/40
    40/40 [==============================] - 281s 7s/step - loss: 0.4569 - accuracy: 0.7811 - val_loss: 0.5115 - val_accuracy: 0.7400
    Epoch 25/40
    40/40 [==============================] - 286s 7s/step - loss: 0.4595 - accuracy: 0.7650 - val_loss: 0.4987 - val_accuracy: 0.7500
    Epoch 26/40
    40/40 [==============================] - 315s 8s/step - loss: 0.4632 - accuracy: 0.7709 - val_loss: 0.5030 - val_accuracy: 0.7200
    Epoch 27/40
    40/40 [==============================] - 274s 7s/step - loss: 0.4530 - accuracy: 0.7823 - val_loss: 0.5023 - val_accuracy: 0.7500
    Epoch 28/40
    40/40 [==============================] - 255s 6s/step - loss: 0.4614 - accuracy: 0.7787 - val_loss: 0.5061 - val_accuracy: 0.7500
    Epoch 29/40
    40/40 [==============================] - 252s 6s/step - loss: 0.4696 - accuracy: 0.7772 - val_loss: 0.5226 - val_accuracy: 0.7000
    Epoch 30/40
    40/40 [==============================] - 256s 6s/step - loss: 0.4574 - accuracy: 0.7787 - val_loss: 0.5110 - val_accuracy: 0.7600
    Epoch 31/40
    40/40 [==============================] - 258s 6s/step - loss: 0.4525 - accuracy: 0.7772 - val_loss: 0.5093 - val_accuracy: 0.7200
    Epoch 32/40
    40/40 [==============================] - 257s 6s/step - loss: 0.4636 - accuracy: 0.7760 - val_loss: 0.5137 - val_accuracy: 0.7300
    Epoch 33/40
    40/40 [==============================] - 262s 7s/step - loss: 0.4679 - accuracy: 0.7760 - val_loss: 0.5064 - val_accuracy: 0.7300
    Epoch 34/40
    40/40 [==============================] - 264s 7s/step - loss: 0.4645 - accuracy: 0.7709 - val_loss: 0.5049 - val_accuracy: 0.7500
    Epoch 35/40
    40/40 [==============================] - 264s 7s/step - loss: 0.4534 - accuracy: 0.7760 - val_loss: 0.5112 - val_accuracy: 0.7600
    Epoch 36/40
    40/40 [==============================] - 261s 7s/step - loss: 0.4546 - accuracy: 0.7807 - val_loss: 0.5260 - val_accuracy: 0.7400
    Epoch 37/40
    40/40 [==============================] - 260s 6s/step - loss: 0.4674 - accuracy: 0.7665 - val_loss: 0.5077 - val_accuracy: 0.7000
    Epoch 38/40
    40/40 [==============================] - 264s 7s/step - loss: 0.4534 - accuracy: 0.7787 - val_loss: 0.5200 - val_accuracy: 0.6900
    Epoch 39/40
    40/40 [==============================] - 273s 7s/step - loss: 0.4708 - accuracy: 0.7791 - val_loss: 0.5044 - val_accuracy: 0.7200
    Epoch 40/40
    40/40 [==============================] - 284s 7s/step - loss: 0.4572 - accuracy: 0.7791 - val_loss: 0.5015 - val_accuracy: 0.7700
    


```python
# Learning curves for training and validation
history_df = pd.DataFrame(history.history)
history_df
     
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loss</th>
      <th>accuracy</th>
      <th>val_loss</th>
      <th>val_accuracy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.505735</td>
      <td>0.750787</td>
      <td>0.528112</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.497136</td>
      <td>0.750000</td>
      <td>0.502762</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.488727</td>
      <td>0.754331</td>
      <td>0.542659</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.497332</td>
      <td>0.744882</td>
      <td>0.509590</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.494970</td>
      <td>0.750000</td>
      <td>0.507774</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.495422</td>
      <td>0.750787</td>
      <td>0.525094</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.499835</td>
      <td>0.755512</td>
      <td>0.534112</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.490680</td>
      <td>0.752362</td>
      <td>0.521754</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.486219</td>
      <td>0.764961</td>
      <td>0.527157</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.469141</td>
      <td>0.770866</td>
      <td>0.501711</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.490986</td>
      <td>0.757087</td>
      <td>0.542883</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.478336</td>
      <td>0.764567</td>
      <td>0.518607</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.477981</td>
      <td>0.757874</td>
      <td>0.505257</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.476191</td>
      <td>0.757480</td>
      <td>0.488488</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.465294</td>
      <td>0.769291</td>
      <td>0.518643</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.474001</td>
      <td>0.764961</td>
      <td>0.548519</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.472718</td>
      <td>0.764567</td>
      <td>0.524578</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.469714</td>
      <td>0.761811</td>
      <td>0.501650</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.479093</td>
      <td>0.755906</td>
      <td>0.508110</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.460460</td>
      <td>0.768898</td>
      <td>0.507503</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.462593</td>
      <td>0.775197</td>
      <td>0.515000</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.460194</td>
      <td>0.783071</td>
      <td>0.522111</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.470398</td>
      <td>0.767323</td>
      <td>0.498419</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.456869</td>
      <td>0.781102</td>
      <td>0.511549</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.459523</td>
      <td>0.764961</td>
      <td>0.498656</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.463156</td>
      <td>0.770866</td>
      <td>0.503049</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.453041</td>
      <td>0.782283</td>
      <td>0.502318</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.461361</td>
      <td>0.778740</td>
      <td>0.506111</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.469640</td>
      <td>0.777165</td>
      <td>0.522572</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.457408</td>
      <td>0.778740</td>
      <td>0.511004</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.452538</td>
      <td>0.777165</td>
      <td>0.509340</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>31</th>
      <td>0.463598</td>
      <td>0.775984</td>
      <td>0.513736</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>32</th>
      <td>0.467859</td>
      <td>0.775984</td>
      <td>0.506446</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>33</th>
      <td>0.464457</td>
      <td>0.770866</td>
      <td>0.504909</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>34</th>
      <td>0.453362</td>
      <td>0.775984</td>
      <td>0.511236</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>35</th>
      <td>0.454581</td>
      <td>0.780709</td>
      <td>0.525957</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>36</th>
      <td>0.467425</td>
      <td>0.766535</td>
      <td>0.507701</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>37</th>
      <td>0.453430</td>
      <td>0.778740</td>
      <td>0.520033</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>38</th>
      <td>0.470754</td>
      <td>0.779134</td>
      <td>0.504431</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>39</th>
      <td>0.457175</td>
      <td>0.779134</td>
      <td>0.501513</td>
      <td>0.77</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12, 8))
sns.lineplot(data=history_df.loc[:, ["accuracy", "val_accuracy"]], palette=['b', 'r'], dashes=False)
sns.set_style("whitegrid")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.title("Training and Validation Accuracy")
     
```




    Text(0.5, 1.0, 'Training and Validation Accuracy')




    
![png](output_25_1.png)
    



```python
X = np.array(X_test)
```


```python
pred = model.predict(X)
threshold = 0.5
predictions = np.where(pred > threshold, 1,0)
```

    10/10 [==============================] - 35s 3s/step
    


```python
test = pd.DataFrame(data = predictions, columns = ["predictions"])
test
test["filename"] = [os.path.basename(i) for i in test_imgs]
test["test_labels"] = y_test
test = test[["filename", "test_labels", "predictions"]]
test
     
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>filename</th>
      <th>test_labels</th>
      <th>predictions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Autistic.0.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Autistic.1.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Autistic.10.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Autistic.100.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Autistic.101.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>295</th>
      <td>Non_Autistic.95.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>296</th>
      <td>Non_Autistic.96.jpg</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>297</th>
      <td>Non_Autistic.97.jpg</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>298</th>
      <td>Non_Autistic.98.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>299</th>
      <td>Non_Autistic.99.jpg</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>300 rows × 3 columns</p>
</div>




```python
model_accuracy = accuracy_score(y_test, predictions)
print("Model Accuracy: {:.2f}%".format(model_accuracy * 100))
```

    Model Accuracy: 74.00%
    


```python
cl_report = classification_report(y_test, predictions)
print(cl_report)
```

                  precision    recall  f1-score   support
    
               0       0.75      0.73      0.74       150
               1       0.73      0.75      0.74       150
    
        accuracy                           0.74       300
       macro avg       0.74      0.74      0.74       300
    weighted avg       0.74      0.74      0.74       300
    
    


```python
cn_matrix= confusion_matrix(y_test, predictions)
cn_matrix
```




    array([[109,  41],
           [ 37, 113]], dtype=int64)




```python
f, ax = plt.subplots(figsize = (8,6))
ax = sns.heatmap(cn_matrix, annot=True,fmt="d")
ax.set_xlabel("Predicted")
ax.set_ylabel("True")
ax.set_title("Confusion Matrix")
```




    Text(0.5, 1.0, 'Confusion Matrix')




    
![png](output_32_1.png)
    


#Xception Model Implementation 


```python
# Calling pre-trained xception model
base_model1 = Xception(include_top=False,weights='imagenet',input_shape=(150,150,3),pooling='avg')
```


```python
# Let's see how many layers are in the xception model
print("Number of layers in the base model: ", len(base_model1.layers))
```

    Number of layers in the base model:  133
    


```python
# Freeze the layers in pre-trained model, we don't need to train again
for layer in base_model1.layers:
   layer.trainable = False
```


```python
model1 = Sequential()
model1.add(base_model1)
model1.add(layers.Dense(512, activation = 'relu'))
model1.add(layers.Dense(units = 256 , activation = 'relu'))
model1.add(Dense(units = 64 , activation = 'relu'))
model1.add(layers.Dropout(0.5))
model1.add(layers.Dense(1, activation = 'sigmoid'))
```


```python
# Create summary of our model
model1.summary()
```

    Model: "sequential_3"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     xception (Functional)       (None, 2048)              20861480  
                                                                     
     dense_6 (Dense)             (None, 512)               1049088   
                                                                     
     dense_7 (Dense)             (None, 256)               131328    
                                                                     
     dense_8 (Dense)             (None, 64)                16448     
                                                                     
     dropout_2 (Dropout)         (None, 64)                0         
                                                                     
     dense_9 (Dense)             (None, 1)                 65        
                                                                     
    =================================================================
    Total params: 22058409 (84.15 MB)
    Trainable params: 1196929 (4.57 MB)
    Non-trainable params: 20861480 (79.58 MB)
    _________________________________________________________________
    


```python
model1.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
```


```python
#  sammeeeeeeee Configure data augumentation and scaling of images to prevent overfitting since we have a small train data
train_datagen = ImageDataGenerator(rescale = 1./255,
                                  rotation_range = 40,
                                  width_shift_range = 0.2,
                                  height_shift_range = 0.2,
                                  shear_range = 0.2,
                                  zoom_range = 0.2,
                                  horizontal_flip = True)

# Only rescaling for validation data
val_datagen = ImageDataGenerator(rescale = 1./255)
     
```


```python
X_test, y_test = read_and_process_image(test_imgs)
del test_imgs
gc.collect()
```




    16756




```python
plt.figure(figsize=(12, 8))
X_test = np.array(X_test)
y_test = np.array(y_test)
sns.countplot(y_val, saturation=1)
plt.title("Test image labels")
     
```




    Text(0.5, 1.0, 'Test image labels')




    
![png](output_42_1.png)
    



```python
# Create test and validation image generator
BATCH_SIZE = 64
X_train = np.array(X_train)
y_train = np.array(y_train)
X_test = np.array(X_test)
y_test = np.array(y_test)
X_val = np.array(X_val)
y_val = np.array(y_val)
train_generator = train_datagen.flow(X_train, y_train, batch_size = BATCH_SIZE)
val_generator = val_datagen.flow(X_val, y_val, batch_size = BATCH_SIZE)
```


```python
# Train the model
#early_stopping = keras.callbacks.EarlyStopping(monitor="val_loss", patience=3)

# Entrenar el modelo
history1 = model1.fit(train_generator,
                              epochs=50,
                              validation_data=val_generator,
                              workers=8,
                              use_multiprocessing=False
                             )
```

    Epoch 1/50
    40/40 [==============================] - 101s 3s/step - loss: 0.5178 - accuracy: 0.7500 - val_loss: 0.5197 - val_accuracy: 0.7500
    Epoch 2/50
    40/40 [==============================] - 104s 3s/step - loss: 0.5196 - accuracy: 0.7417 - val_loss: 0.5283 - val_accuracy: 0.7500
    Epoch 3/50
    40/40 [==============================] - 107s 3s/step - loss: 0.5137 - accuracy: 0.7492 - val_loss: 0.5255 - val_accuracy: 0.7200
    Epoch 4/50
    40/40 [==============================] - 104s 3s/step - loss: 0.5215 - accuracy: 0.7398 - val_loss: 0.4859 - val_accuracy: 0.7300
    Epoch 5/50
    40/40 [==============================] - 104s 3s/step - loss: 0.5055 - accuracy: 0.7437 - val_loss: 0.4774 - val_accuracy: 0.7500
    Epoch 6/50
    40/40 [==============================] - 110s 3s/step - loss: 0.5045 - accuracy: 0.7535 - val_loss: 0.5246 - val_accuracy: 0.7400
    Epoch 7/50
    40/40 [==============================] - 114s 3s/step - loss: 0.4930 - accuracy: 0.7567 - val_loss: 0.4999 - val_accuracy: 0.7200
    Epoch 8/50
    40/40 [==============================] - 110s 3s/step - loss: 0.5078 - accuracy: 0.7398 - val_loss: 0.4920 - val_accuracy: 0.7300
    Epoch 9/50
    40/40 [==============================] - 114s 3s/step - loss: 0.4843 - accuracy: 0.7732 - val_loss: 0.5210 - val_accuracy: 0.7300
    Epoch 10/50
    40/40 [==============================] - 114s 3s/step - loss: 0.5111 - accuracy: 0.7480 - val_loss: 0.5076 - val_accuracy: 0.7300
    Epoch 11/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4839 - accuracy: 0.7618 - val_loss: 0.4979 - val_accuracy: 0.7500
    Epoch 12/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4993 - accuracy: 0.7622 - val_loss: 0.4863 - val_accuracy: 0.7500
    Epoch 13/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4966 - accuracy: 0.7630 - val_loss: 0.5005 - val_accuracy: 0.7600
    Epoch 14/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4888 - accuracy: 0.7594 - val_loss: 0.4972 - val_accuracy: 0.7400
    Epoch 15/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4819 - accuracy: 0.7642 - val_loss: 0.5310 - val_accuracy: 0.7400
    Epoch 16/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4833 - accuracy: 0.7594 - val_loss: 0.4985 - val_accuracy: 0.7800
    Epoch 17/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4936 - accuracy: 0.7516 - val_loss: 0.4823 - val_accuracy: 0.7400
    Epoch 18/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4816 - accuracy: 0.7594 - val_loss: 0.5413 - val_accuracy: 0.7500
    Epoch 19/50
    40/40 [==============================] - 133s 3s/step - loss: 0.4857 - accuracy: 0.7630 - val_loss: 0.5204 - val_accuracy: 0.7400
    Epoch 20/50
    40/40 [==============================] - 135s 3s/step - loss: 0.4868 - accuracy: 0.7685 - val_loss: 0.4842 - val_accuracy: 0.7700
    Epoch 21/50
    40/40 [==============================] - 134s 3s/step - loss: 0.4777 - accuracy: 0.7618 - val_loss: 0.5065 - val_accuracy: 0.7700
    Epoch 22/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4899 - accuracy: 0.7547 - val_loss: 0.4836 - val_accuracy: 0.7300
    Epoch 23/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4759 - accuracy: 0.7665 - val_loss: 0.4697 - val_accuracy: 0.7800
    Epoch 24/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4635 - accuracy: 0.7772 - val_loss: 0.4986 - val_accuracy: 0.7500
    Epoch 25/50
    40/40 [==============================] - 118s 3s/step - loss: 0.4772 - accuracy: 0.7634 - val_loss: 0.4939 - val_accuracy: 0.7400
    Epoch 26/50
    40/40 [==============================] - 118s 3s/step - loss: 0.4752 - accuracy: 0.7720 - val_loss: 0.5189 - val_accuracy: 0.7400
    Epoch 27/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4625 - accuracy: 0.7724 - val_loss: 0.5082 - val_accuracy: 0.7700
    Epoch 28/50
    40/40 [==============================] - 114s 3s/step - loss: 0.4739 - accuracy: 0.7732 - val_loss: 0.5444 - val_accuracy: 0.6800
    Epoch 29/50
    40/40 [==============================] - 114s 3s/step - loss: 0.4631 - accuracy: 0.7803 - val_loss: 0.4791 - val_accuracy: 0.7800
    Epoch 30/50
    40/40 [==============================] - 114s 3s/step - loss: 0.4686 - accuracy: 0.7709 - val_loss: 0.5128 - val_accuracy: 0.7500
    Epoch 31/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4625 - accuracy: 0.7776 - val_loss: 0.4920 - val_accuracy: 0.7300
    Epoch 32/50
    40/40 [==============================] - 114s 3s/step - loss: 0.4775 - accuracy: 0.7744 - val_loss: 0.5021 - val_accuracy: 0.7800
    Epoch 33/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4611 - accuracy: 0.7728 - val_loss: 0.5085 - val_accuracy: 0.7600
    Epoch 34/50
    40/40 [==============================] - 113s 3s/step - loss: 0.4509 - accuracy: 0.7795 - val_loss: 0.4537 - val_accuracy: 0.8000
    Epoch 35/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4587 - accuracy: 0.7783 - val_loss: 0.4586 - val_accuracy: 0.8100
    Epoch 36/50
    40/40 [==============================] - 113s 3s/step - loss: 0.4525 - accuracy: 0.7858 - val_loss: 0.5160 - val_accuracy: 0.7800
    Epoch 37/50
    40/40 [==============================] - 121s 3s/step - loss: 0.4459 - accuracy: 0.7902 - val_loss: 0.5399 - val_accuracy: 0.7700
    Epoch 38/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4616 - accuracy: 0.7819 - val_loss: 0.4717 - val_accuracy: 0.7700
    Epoch 39/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4515 - accuracy: 0.7799 - val_loss: 0.4830 - val_accuracy: 0.7900
    Epoch 40/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4470 - accuracy: 0.7732 - val_loss: 0.5290 - val_accuracy: 0.7600
    Epoch 41/50
    40/40 [==============================] - 128s 3s/step - loss: 0.4485 - accuracy: 0.7803 - val_loss: 0.4720 - val_accuracy: 0.7800
    Epoch 42/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4461 - accuracy: 0.7819 - val_loss: 0.5017 - val_accuracy: 0.7100
    Epoch 43/50
    40/40 [==============================] - 115s 3s/step - loss: 0.4286 - accuracy: 0.7965 - val_loss: 0.4806 - val_accuracy: 0.7700
    Epoch 44/50
    40/40 [==============================] - 118s 3s/step - loss: 0.4507 - accuracy: 0.7791 - val_loss: 0.4821 - val_accuracy: 0.7900
    Epoch 45/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4442 - accuracy: 0.7878 - val_loss: 0.4977 - val_accuracy: 0.7600
    Epoch 46/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4545 - accuracy: 0.7882 - val_loss: 0.4483 - val_accuracy: 0.8300
    Epoch 47/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4360 - accuracy: 0.7878 - val_loss: 0.4564 - val_accuracy: 0.7900
    Epoch 48/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4476 - accuracy: 0.7843 - val_loss: 0.5514 - val_accuracy: 0.7400
    Epoch 49/50
    40/40 [==============================] - 116s 3s/step - loss: 0.4311 - accuracy: 0.7988 - val_loss: 0.4809 - val_accuracy: 0.7800
    Epoch 50/50
    40/40 [==============================] - 117s 3s/step - loss: 0.4305 - accuracy: 0.8063 - val_loss: 0.4809 - val_accuracy: 0.7700
    


```python
# Learning curves for training and validation
history_df1 = pd.DataFrame(history1.history)
history_df1
     
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loss</th>
      <th>accuracy</th>
      <th>val_loss</th>
      <th>val_accuracy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.517791</td>
      <td>0.750000</td>
      <td>0.519699</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.519585</td>
      <td>0.741732</td>
      <td>0.528339</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.513712</td>
      <td>0.749213</td>
      <td>0.525468</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.521528</td>
      <td>0.739764</td>
      <td>0.485907</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.505507</td>
      <td>0.743701</td>
      <td>0.477427</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.504493</td>
      <td>0.753543</td>
      <td>0.524577</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.492967</td>
      <td>0.756693</td>
      <td>0.499876</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.507826</td>
      <td>0.739764</td>
      <td>0.492029</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.484269</td>
      <td>0.773228</td>
      <td>0.520985</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.511149</td>
      <td>0.748031</td>
      <td>0.507629</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.483924</td>
      <td>0.761811</td>
      <td>0.497904</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.499312</td>
      <td>0.762205</td>
      <td>0.486297</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.496615</td>
      <td>0.762992</td>
      <td>0.500484</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.488845</td>
      <td>0.759449</td>
      <td>0.497169</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.481948</td>
      <td>0.764173</td>
      <td>0.530958</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.483291</td>
      <td>0.759449</td>
      <td>0.498538</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.493607</td>
      <td>0.751575</td>
      <td>0.482322</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.481574</td>
      <td>0.759449</td>
      <td>0.541336</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.485664</td>
      <td>0.762992</td>
      <td>0.520358</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.486821</td>
      <td>0.768504</td>
      <td>0.484193</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.477735</td>
      <td>0.761811</td>
      <td>0.506460</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.489859</td>
      <td>0.754724</td>
      <td>0.483553</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.475936</td>
      <td>0.766535</td>
      <td>0.469719</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.463487</td>
      <td>0.777165</td>
      <td>0.498567</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.477229</td>
      <td>0.763386</td>
      <td>0.493905</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.475181</td>
      <td>0.772047</td>
      <td>0.518917</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.462469</td>
      <td>0.772441</td>
      <td>0.508199</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.473852</td>
      <td>0.773228</td>
      <td>0.544370</td>
      <td>0.68</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.463065</td>
      <td>0.780315</td>
      <td>0.479051</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.468594</td>
      <td>0.770866</td>
      <td>0.512841</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.462498</td>
      <td>0.777559</td>
      <td>0.492045</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>31</th>
      <td>0.477471</td>
      <td>0.774409</td>
      <td>0.502136</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>32</th>
      <td>0.461120</td>
      <td>0.772835</td>
      <td>0.508519</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>33</th>
      <td>0.450922</td>
      <td>0.779528</td>
      <td>0.453676</td>
      <td>0.80</td>
    </tr>
    <tr>
      <th>34</th>
      <td>0.458696</td>
      <td>0.778346</td>
      <td>0.458643</td>
      <td>0.81</td>
    </tr>
    <tr>
      <th>35</th>
      <td>0.452497</td>
      <td>0.785827</td>
      <td>0.515975</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>36</th>
      <td>0.445875</td>
      <td>0.790157</td>
      <td>0.539895</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>37</th>
      <td>0.461611</td>
      <td>0.781890</td>
      <td>0.471709</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>38</th>
      <td>0.451461</td>
      <td>0.779921</td>
      <td>0.482999</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>39</th>
      <td>0.446970</td>
      <td>0.773228</td>
      <td>0.529018</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>40</th>
      <td>0.448459</td>
      <td>0.780315</td>
      <td>0.471964</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>41</th>
      <td>0.446086</td>
      <td>0.781890</td>
      <td>0.501659</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>42</th>
      <td>0.428631</td>
      <td>0.796457</td>
      <td>0.480586</td>
      <td>0.77</td>
    </tr>
    <tr>
      <th>43</th>
      <td>0.450713</td>
      <td>0.779134</td>
      <td>0.482097</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>44</th>
      <td>0.444218</td>
      <td>0.787795</td>
      <td>0.497654</td>
      <td>0.76</td>
    </tr>
    <tr>
      <th>45</th>
      <td>0.454526</td>
      <td>0.788189</td>
      <td>0.448311</td>
      <td>0.83</td>
    </tr>
    <tr>
      <th>46</th>
      <td>0.435995</td>
      <td>0.787795</td>
      <td>0.456410</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>47</th>
      <td>0.447650</td>
      <td>0.784252</td>
      <td>0.551432</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>48</th>
      <td>0.431126</td>
      <td>0.798819</td>
      <td>0.480928</td>
      <td>0.78</td>
    </tr>
    <tr>
      <th>49</th>
      <td>0.430450</td>
      <td>0.806299</td>
      <td>0.480950</td>
      <td>0.77</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12, 8))
sns.lineplot(data=history_df1.loc[:, ["accuracy", "val_accuracy"]], palette=['b', 'r'], dashes=False)
sns.set_style("whitegrid")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.title("Training and Validation Accuracy")
     
```




    Text(0.5, 1.0, 'Training and Validation Accuracy')




    
![png](output_46_1.png)
    



```python
X = np.array(X_test)
#sameeeee ends
```


```python
pred1 = model1.predict(X)
threshold = 0.5
predictions1 = np.where(pred1 > threshold, 1,0)
```

    10/10 [==============================] - 15s 1s/step
    


```python
test1 = pd.DataFrame(data = predictions1, columns = ["predictions"])
test1
test1["filename"] = [os.path.basename(i) for i in test_imgs]
test1["test_labels"] = y_test
test1 = test1[["filename", "test_labels", "predictions"]]
test1
     
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>filename</th>
      <th>test_labels</th>
      <th>predictions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Autistic.0.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Autistic.1.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Autistic.10.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Autistic.100.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Autistic.101.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>295</th>
      <td>Non_Autistic.95.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>296</th>
      <td>Non_Autistic.96.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>297</th>
      <td>Non_Autistic.97.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>298</th>
      <td>Non_Autistic.98.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>299</th>
      <td>Non_Autistic.99.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>300 rows × 3 columns</p>
</div>




```python
model_accuracy1 = accuracy_score(y_test, predictions1)
print("Model Accuracy: {:.2f}%".format(model_accuracy1 * 100))
```

    Model Accuracy: 50.00%
    


```python
cl_report1 = classification_report(y_test, predictions1)
print(cl_report1)
```

                  precision    recall  f1-score   support
    
               0       0.50      0.02      0.04       150
               1       0.50      0.98      0.66       150
    
        accuracy                           0.50       300
       macro avg       0.50      0.50      0.35       300
    weighted avg       0.50      0.50      0.35       300
    
    


```python
cn_matrix1= confusion_matrix(y_test, predictions1)
cn_matrix1
```




    array([[  3, 147],
           [  3, 147]], dtype=int64)




```python
f1, ax1 = plt.subplots(figsize = (8,6))
ax1 = sns.heatmap(cn_matrix1, annot=True,fmt="d")
ax1.set_xlabel("Predicted")
ax1.set_ylabel("True")
ax1.set_title("Confusion Matrix")
```




    Text(0.5, 1.0, 'Confusion Matrix')




    
![png](output_53_1.png)
    


#Resnet Model Implementation


```python
# Calling pre-trained resnet model
base_model2 = ResNet50(include_top=False,weights='imagenet',input_shape=(150,150,3))
```


```python
# Let's see how many layers are in the resnet model
print("Number of layers in the base model: ", len(base_model2.layers))
```

    Number of layers in the base model:  175
    


```python
# Freeze the layers in pre-trained model, we don't need to train again
for layer in base_model2.layers:
   layer.trainable = False
```


```python
# Create our classifier model, connect pre-trained model Resnet to our model
model2 = keras.models.Sequential()
model2.add(base_model2)
model2.add(layers.MaxPooling2D(pool_size=(2, 2)))
model2.add(layers.Flatten())
model2.add(layers.Dense(512, activation = 'relu'))
model2.add(layers.Dropout(0.5))
model2.add(layers.Dense(1, activation = 'sigmoid'))
```


```python
# Create summary of our model
model2.summary()
```

    Model: "sequential_4"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     resnet50 (Functional)       (None, 5, 5, 2048)        23587712  
                                                                     
     max_pooling2d_1 (MaxPoolin  (None, 2, 2, 2048)        0         
     g2D)                                                            
                                                                     
     flatten_1 (Flatten)         (None, 8192)              0         
                                                                     
     dense_10 (Dense)            (None, 512)               4194816   
                                                                     
     dropout_3 (Dropout)         (None, 512)               0         
                                                                     
     dense_11 (Dense)            (None, 1)                 513       
                                                                     
    =================================================================
    Total params: 27783041 (105.98 MB)
    Trainable params: 4195329 (16.00 MB)
    Non-trainable params: 23587712 (89.98 MB)
    _________________________________________________________________
    


```python
model2.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
```


```python
# Configure data augumentation and scaling of images to prevent overfitting since we have a small train data
train_datagen = ImageDataGenerator(rescale = 1./255,
                                  rotation_range = 40,
                                  width_shift_range = 0.2,
                                  height_shift_range = 0.2,
                                  shear_range = 0.2,
                                  zoom_range = 0.2,
                                  horizontal_flip = True)

# Only rescaling for validation data
val_datagen = ImageDataGenerator(rescale = 1./255)
     
```


```python
X_test, y_test = read_and_process_image(test_imgs)
del test_imgs
gc.collect()
```




    35




```python
plt.figure(figsize=(12, 8))
X_test = np.array(X_test)
y_test = np.array(y_test)
sns.countplot(y_val, saturation=1)
plt.title("Test image labels")
     
```




    Text(0.5, 1.0, 'Test image labels')




    
![png](output_63_1.png)
    



```python
# Create test and validation image generator
BATCH_SIZE = 64
X_train = np.array(X_train)
y_train = np.array(y_train)
X_test = np.array(X_test)
y_test = np.array(y_test)
X_val = np.array(X_val)
y_val = np.array(y_val)
train_generator = train_datagen.flow(X_train, y_train, batch_size = BATCH_SIZE)
val_generator = val_datagen.flow(X_val, y_val, batch_size = BATCH_SIZE)
```


```python
# Train the model
#early_stopping = keras.callbacks.EarlyStopping(monitor="val_loss", patience=3)

# Entrenar el modelo
history2 = model2.fit(train_generator,
                              epochs=50,
                              validation_data=val_generator,
                              #callbacks=[early_stopping],
                              workers=8,
                              use_multiprocessing=False
                             )
```

    Epoch 1/50
    40/40 [==============================] - 123s 3s/step - loss: 0.8129 - accuracy: 0.5268 - val_loss: 0.6511 - val_accuracy: 0.5800
    Epoch 2/50
    40/40 [==============================] - 123s 3s/step - loss: 0.6929 - accuracy: 0.5496 - val_loss: 0.6534 - val_accuracy: 0.6500
    Epoch 3/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6744 - accuracy: 0.5780 - val_loss: 0.6366 - val_accuracy: 0.6600
    Epoch 4/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6704 - accuracy: 0.5764 - val_loss: 0.6335 - val_accuracy: 0.7000
    Epoch 5/50
    40/40 [==============================] - 118s 3s/step - loss: 0.6673 - accuracy: 0.5996 - val_loss: 0.6532 - val_accuracy: 0.5800
    Epoch 6/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6743 - accuracy: 0.5768 - val_loss: 0.6368 - val_accuracy: 0.6000
    Epoch 7/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6707 - accuracy: 0.5823 - val_loss: 0.6368 - val_accuracy: 0.7200
    Epoch 8/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6675 - accuracy: 0.5965 - val_loss: 0.6244 - val_accuracy: 0.6700
    Epoch 9/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6713 - accuracy: 0.5776 - val_loss: 0.6293 - val_accuracy: 0.7000
    Epoch 10/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6718 - accuracy: 0.5850 - val_loss: 0.6367 - val_accuracy: 0.6900
    Epoch 11/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6676 - accuracy: 0.5862 - val_loss: 0.6143 - val_accuracy: 0.6900
    Epoch 12/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6615 - accuracy: 0.6000 - val_loss: 0.6235 - val_accuracy: 0.7100
    Epoch 13/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6687 - accuracy: 0.6012 - val_loss: 0.6142 - val_accuracy: 0.6600
    Epoch 14/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6670 - accuracy: 0.5906 - val_loss: 0.6204 - val_accuracy: 0.7100
    Epoch 15/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6612 - accuracy: 0.6197 - val_loss: 0.6088 - val_accuracy: 0.6900
    Epoch 16/50
    40/40 [==============================] - 124s 3s/step - loss: 0.6609 - accuracy: 0.6130 - val_loss: 0.6177 - val_accuracy: 0.6700
    Epoch 17/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6606 - accuracy: 0.6008 - val_loss: 0.6201 - val_accuracy: 0.7000
    Epoch 18/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6592 - accuracy: 0.5996 - val_loss: 0.6045 - val_accuracy: 0.7000
    Epoch 19/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6537 - accuracy: 0.6217 - val_loss: 0.6010 - val_accuracy: 0.7100
    Epoch 20/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6609 - accuracy: 0.6161 - val_loss: 0.6091 - val_accuracy: 0.6600
    Epoch 21/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6639 - accuracy: 0.6059 - val_loss: 0.6124 - val_accuracy: 0.7000
    Epoch 22/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6571 - accuracy: 0.6134 - val_loss: 0.6288 - val_accuracy: 0.6300
    Epoch 23/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6669 - accuracy: 0.5906 - val_loss: 0.6326 - val_accuracy: 0.6800
    Epoch 24/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6629 - accuracy: 0.5941 - val_loss: 0.6065 - val_accuracy: 0.7100
    Epoch 25/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6567 - accuracy: 0.6000 - val_loss: 0.5919 - val_accuracy: 0.7200
    Epoch 26/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6617 - accuracy: 0.6004 - val_loss: 0.5970 - val_accuracy: 0.6900
    Epoch 27/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6607 - accuracy: 0.6071 - val_loss: 0.6098 - val_accuracy: 0.6600
    Epoch 28/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6670 - accuracy: 0.5961 - val_loss: 0.6102 - val_accuracy: 0.7300
    Epoch 29/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6553 - accuracy: 0.6157 - val_loss: 0.5964 - val_accuracy: 0.6900
    Epoch 30/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6608 - accuracy: 0.6098 - val_loss: 0.6350 - val_accuracy: 0.7300
    Epoch 31/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6622 - accuracy: 0.5980 - val_loss: 0.6245 - val_accuracy: 0.6900
    Epoch 32/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6548 - accuracy: 0.6161 - val_loss: 0.6086 - val_accuracy: 0.7000
    Epoch 33/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6639 - accuracy: 0.5961 - val_loss: 0.6153 - val_accuracy: 0.6600
    Epoch 34/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6616 - accuracy: 0.6016 - val_loss: 0.6217 - val_accuracy: 0.7100
    Epoch 35/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6669 - accuracy: 0.5823 - val_loss: 0.6236 - val_accuracy: 0.7100
    Epoch 36/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6587 - accuracy: 0.6043 - val_loss: 0.6085 - val_accuracy: 0.6900
    Epoch 37/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6606 - accuracy: 0.5913 - val_loss: 0.5870 - val_accuracy: 0.7200
    Epoch 38/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6537 - accuracy: 0.5961 - val_loss: 0.6135 - val_accuracy: 0.6800
    Epoch 39/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6594 - accuracy: 0.6161 - val_loss: 0.5988 - val_accuracy: 0.6800
    Epoch 40/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6583 - accuracy: 0.6091 - val_loss: 0.6241 - val_accuracy: 0.7200
    Epoch 41/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6587 - accuracy: 0.6091 - val_loss: 0.6261 - val_accuracy: 0.7500
    Epoch 42/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6642 - accuracy: 0.5945 - val_loss: 0.6022 - val_accuracy: 0.6900
    Epoch 43/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6662 - accuracy: 0.6004 - val_loss: 0.6123 - val_accuracy: 0.6800
    Epoch 44/50
    40/40 [==============================] - 121s 3s/step - loss: 0.6553 - accuracy: 0.5980 - val_loss: 0.6059 - val_accuracy: 0.7400
    Epoch 45/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6554 - accuracy: 0.6181 - val_loss: 0.5983 - val_accuracy: 0.7200
    Epoch 46/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6632 - accuracy: 0.6004 - val_loss: 0.5910 - val_accuracy: 0.7000
    Epoch 47/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6542 - accuracy: 0.6110 - val_loss: 0.5949 - val_accuracy: 0.7200
    Epoch 48/50
    40/40 [==============================] - 120s 3s/step - loss: 0.6510 - accuracy: 0.6146 - val_loss: 0.6084 - val_accuracy: 0.7100
    Epoch 49/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6649 - accuracy: 0.5961 - val_loss: 0.6078 - val_accuracy: 0.7000
    Epoch 50/50
    40/40 [==============================] - 119s 3s/step - loss: 0.6575 - accuracy: 0.6083 - val_loss: 0.5960 - val_accuracy: 0.6900
    


```python
# Learning curves for training and validation
history_df2 = pd.DataFrame(history2.history)
history_df2
     
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>loss</th>
      <th>accuracy</th>
      <th>val_loss</th>
      <th>val_accuracy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.812886</td>
      <td>0.526772</td>
      <td>0.651051</td>
      <td>0.58</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.692915</td>
      <td>0.549606</td>
      <td>0.653415</td>
      <td>0.65</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.674420</td>
      <td>0.577953</td>
      <td>0.636624</td>
      <td>0.66</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.670438</td>
      <td>0.576378</td>
      <td>0.633454</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.667276</td>
      <td>0.599606</td>
      <td>0.653241</td>
      <td>0.58</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.674304</td>
      <td>0.576772</td>
      <td>0.636835</td>
      <td>0.60</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.670689</td>
      <td>0.582283</td>
      <td>0.636766</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.667503</td>
      <td>0.596457</td>
      <td>0.624381</td>
      <td>0.67</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.671264</td>
      <td>0.577559</td>
      <td>0.629304</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.671840</td>
      <td>0.585039</td>
      <td>0.636700</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.667550</td>
      <td>0.586220</td>
      <td>0.614349</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.661519</td>
      <td>0.600000</td>
      <td>0.623465</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.668715</td>
      <td>0.601181</td>
      <td>0.614187</td>
      <td>0.66</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.666971</td>
      <td>0.590551</td>
      <td>0.620350</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.661188</td>
      <td>0.619685</td>
      <td>0.608772</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.660946</td>
      <td>0.612992</td>
      <td>0.617706</td>
      <td>0.67</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.660641</td>
      <td>0.600787</td>
      <td>0.620107</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.659226</td>
      <td>0.599606</td>
      <td>0.604507</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.653699</td>
      <td>0.621654</td>
      <td>0.601009</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.660912</td>
      <td>0.616142</td>
      <td>0.609109</td>
      <td>0.66</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.663929</td>
      <td>0.605906</td>
      <td>0.612378</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.657103</td>
      <td>0.613386</td>
      <td>0.628767</td>
      <td>0.63</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0.666950</td>
      <td>0.590551</td>
      <td>0.632569</td>
      <td>0.68</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.662900</td>
      <td>0.594095</td>
      <td>0.606531</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0.656659</td>
      <td>0.600000</td>
      <td>0.591866</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.661748</td>
      <td>0.600394</td>
      <td>0.596988</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.660717</td>
      <td>0.607087</td>
      <td>0.609763</td>
      <td>0.66</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.667038</td>
      <td>0.596063</td>
      <td>0.610189</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.655294</td>
      <td>0.615748</td>
      <td>0.596424</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.660829</td>
      <td>0.609843</td>
      <td>0.635011</td>
      <td>0.73</td>
    </tr>
    <tr>
      <th>30</th>
      <td>0.662209</td>
      <td>0.598032</td>
      <td>0.624451</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>31</th>
      <td>0.654841</td>
      <td>0.616142</td>
      <td>0.608567</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>32</th>
      <td>0.663890</td>
      <td>0.596063</td>
      <td>0.615334</td>
      <td>0.66</td>
    </tr>
    <tr>
      <th>33</th>
      <td>0.661632</td>
      <td>0.601575</td>
      <td>0.621718</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>34</th>
      <td>0.666873</td>
      <td>0.582283</td>
      <td>0.623587</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>35</th>
      <td>0.658658</td>
      <td>0.604331</td>
      <td>0.608500</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>36</th>
      <td>0.660600</td>
      <td>0.591339</td>
      <td>0.586970</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>37</th>
      <td>0.653665</td>
      <td>0.596063</td>
      <td>0.613547</td>
      <td>0.68</td>
    </tr>
    <tr>
      <th>38</th>
      <td>0.659382</td>
      <td>0.616142</td>
      <td>0.598842</td>
      <td>0.68</td>
    </tr>
    <tr>
      <th>39</th>
      <td>0.658275</td>
      <td>0.609055</td>
      <td>0.624118</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>40</th>
      <td>0.658676</td>
      <td>0.609055</td>
      <td>0.626100</td>
      <td>0.75</td>
    </tr>
    <tr>
      <th>41</th>
      <td>0.664180</td>
      <td>0.594488</td>
      <td>0.602209</td>
      <td>0.69</td>
    </tr>
    <tr>
      <th>42</th>
      <td>0.666220</td>
      <td>0.600394</td>
      <td>0.612311</td>
      <td>0.68</td>
    </tr>
    <tr>
      <th>43</th>
      <td>0.655303</td>
      <td>0.598032</td>
      <td>0.605915</td>
      <td>0.74</td>
    </tr>
    <tr>
      <th>44</th>
      <td>0.655442</td>
      <td>0.618110</td>
      <td>0.598263</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>45</th>
      <td>0.663159</td>
      <td>0.600394</td>
      <td>0.591020</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>46</th>
      <td>0.654172</td>
      <td>0.611024</td>
      <td>0.594943</td>
      <td>0.72</td>
    </tr>
    <tr>
      <th>47</th>
      <td>0.651039</td>
      <td>0.614567</td>
      <td>0.608418</td>
      <td>0.71</td>
    </tr>
    <tr>
      <th>48</th>
      <td>0.664878</td>
      <td>0.596063</td>
      <td>0.607817</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>49</th>
      <td>0.657507</td>
      <td>0.608268</td>
      <td>0.596040</td>
      <td>0.69</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12, 8))
sns.lineplot(data=history_df2.loc[:, ["loss", "val_loss"]], palette=['b', 'r'], dashes=False)
sns.set_style("whitegrid")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Training and Validation Loss")
```




    Text(0.5, 1.0, 'Training and Validation Loss')




    
![png](output_67_1.png)
    



```python
X = np.array(X_test)
```


```python
pred2 = model2.predict(X)
threshold = 0.5
predictions2 = np.where(pred2 > threshold, 1,0)
```

    10/10 [==============================] - 15s 2s/step
    


```python
test2 = pd.DataFrame(data = predictions2, columns = ["predictions"])
test2
test2["filename"] = [os.path.basename(i) for i in test_imgs]
test2["test_labels"] = y_test
test2 = test2[["filename", "test_labels", "predictions"]]
test2
     
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>filename</th>
      <th>test_labels</th>
      <th>predictions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Autistic.0.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Autistic.1.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Autistic.10.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Autistic.100.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Autistic.101.jpg</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>295</th>
      <td>Non_Autistic.95.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>296</th>
      <td>Non_Autistic.96.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>297</th>
      <td>Non_Autistic.97.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>298</th>
      <td>Non_Autistic.98.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>299</th>
      <td>Non_Autistic.99.jpg</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>300 rows × 3 columns</p>
</div>




```python
model_accuracy2 = accuracy_score(y_test, predictions2)
print("Model Accuracy: {:.2f}%".format(model_accuracy2 * 100))
```

    Model Accuracy: 50.00%
    


```python
cl_report2 = classification_report(y_test, predictions2)
print(cl_report2)
```

                  precision    recall  f1-score   support
    
               0       0.00      0.00      0.00       150
               1       0.50      1.00      0.67       150
    
        accuracy                           0.50       300
       macro avg       0.25      0.50      0.33       300
    weighted avg       0.25      0.50      0.33       300
    
    

    C:\Users\dhwan\anaconda3\Lib\site-packages\sklearn\metrics\_classification.py:1469: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    C:\Users\dhwan\anaconda3\Lib\site-packages\sklearn\metrics\_classification.py:1469: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    C:\Users\dhwan\anaconda3\Lib\site-packages\sklearn\metrics\_classification.py:1469: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    


```python
cn_matrix2= confusion_matrix(y_test, predictions2)
cn_matrix2
```




    array([[  0, 150],
           [  0, 150]], dtype=int64)




```python
f2, ax2 = plt.subplots(figsize = (8,6))
ax2 = sns.heatmap(cn_matrix2, annot=True,fmt="d")
ax2.set_xlabel("Predicted")
ax2.set_ylabel("True")
ax2.set_title("Confusion Matrix")
```




    Text(0.5, 1.0, 'Confusion Matrix')




    
![png](output_74_1.png)
    



```python

```
